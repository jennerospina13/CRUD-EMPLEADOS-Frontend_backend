const express = require('express');
const router = express.Router();

const Empleado = require('../models/empleado');

const empleadoCtrl = {};

// Obtener todos los empleados
empleadoCtrl.getEmpleados = async (req, res) => {
    try {
        const empleados = await Empleado.find();
        res.json(empleados);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener empleados' });
    }
};

// Crear un empleado
empleadoCtrl.createEmpleado = async (req, res) => {
    try {
        const nuevoEmpleado = new Empleado(req.body);
        await nuevoEmpleado.save();
        res.status(201).json(nuevoEmpleado);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear empleado' });
    }
};

// Obtener un solo empleado
empleadoCtrl.getUnicoEmpleado = async (req, res) => {
    try {
        const empleado = await Empleado.findById(req.params.id);
        if (!empleado) {
            return res.status(404).json({ error: 'Empleado no encontrado' });
        }
        res.json(empleado);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener el empleado' });
    }
};

// Actualizar un empleado
empleadoCtrl.editarEmpleado = async (req, res) => {
    try {
        const empleado = await Empleado.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!empleado) {
            return res.status(404).json({ error: 'Empleado no encontrado' });
        }
        res.json(empleado);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar empleado' });
    }
};

// Eliminar un empleado
empleadoCtrl.eliminarEmpleado = async (req, res) => {
    try {
        const empleado = await Empleado.findByIdAndDelete(req.params.id);
        if (!empleado) {
            return res.status(404).json({ error: 'Empleado no encontrado' });
        }
        res.json({ message: 'Empleado eliminado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar empleado' });
    }
};

module.exports = empleadoCtrl;