const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/empleados', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB conectado'))
.catch(err => console.error('Error de conexión:', err));